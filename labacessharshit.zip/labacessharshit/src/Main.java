import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class Main {
    public static void main(String[] args) {
        // Create Frame
        JFrame f = new JFrame("SUN Lab Access System");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(400, 300);

        // Create components
        JLabel lblID = new JLabel("Student ID: ");
        lblID.setBounds(50, 50, 100, 30);
        JTextField txtID = new JTextField();
        txtID.setBounds(150, 50, 150, 30);
        JButton btnAdd = new JButton("Add Record");
        btnAdd.setBounds(50, 100, 250, 30);

        // Add components to frame
        f.add(lblID);
        f.add(txtID);
        f.add(btnAdd);

        // Action for button click
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String studentID = txtID.getText();

                try {
                    // Connect to database
                    Connection con = DriverManager.getConnection("jdbc:derby:C:/Users/Naman/Desktop/labdbh", "harshit", "compass");

                    // Insert record
                    String query = "INSERT INTO AccessRecord (studentID, timestamp) VALUES (?, ?)";
                    PreparedStatement ps = con.prepareStatement(query);
                    ps.setString(1, studentID);
                    ps.executeUpdate();
                    ps.close();
                    con.close();

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Show frame
        f.setLayout(null);
        f.setVisible(true);
    }
}