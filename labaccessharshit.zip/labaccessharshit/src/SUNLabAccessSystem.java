import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class SUNLabAccessSystem {
    public static void main(String[] args) {
        // User Swipe Interface
        JFrame swipeFrame = new JFrame("SUN Lab Swipe Card System");
        swipeFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        swipeFrame.setSize(400, 300);

        JLabel lblID = new JLabel("User ID: ");
        lblID.setBounds(50, 50, 100, 30);
        JTextField txtID = new JTextField();
        txtID.setBounds(150, 50, 150, 30);
        JButton btnSwipe = new JButton("Swipe Card");
        btnSwipe.setBounds(50, 100, 250, 30);
        JButton btnAdmin = new JButton("Admin Panel");
        btnAdmin.setBounds(50, 150, 250, 30);

        swipeFrame.add(lblID);
        swipeFrame.add(txtID);
        swipeFrame.add(btnSwipe);
        swipeFrame.add(btnAdmin);

        btnSwipe.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/SunLabAccess", "root", "BErAtonouS10!");
                    String query = "INSERT INTO AccessRecord (studentID, timestamp) VALUES (?, NOW())";
                    PreparedStatement ps = con.prepareStatement(query);
                    ps.setInt(1, Integer.parseInt(txtID.getText()));
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(swipeFrame, "Access recorded for User ID: " + txtID.getText() + " at " + new java.util.Date());
                    ps.close();
                    con.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        btnAdmin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                openAdminPanel();
            }
        });

        swipeFrame.setLayout(null);
        swipeFrame.setVisible(true);
    }

    public static void openAdminPanel() {
        JFrame adminFrame = new JFrame("Admin Panel");
        adminFrame.setSize(700, 600);

        JTextArea recordsArea = new JTextArea();
        recordsArea.setBounds(50, 50, 600, 300);
        JScrollPane scroll = new JScrollPane(recordsArea);
        scroll.setBounds(50, 50, 600, 300);
        JButton btnFetchAll = new JButton("Fetch All Records");
        btnFetchAll.setBounds(50, 400, 200, 30);
        JTextField filterField = new JTextField();
        filterField.setBounds(270, 400, 150, 30);
        JButton btnSearch = new JButton("Search by ID");
        btnSearch.setBounds(440, 400, 200, 30);

        adminFrame.add(scroll);
        adminFrame.add(btnFetchAll);
        adminFrame.add(filterField);
        adminFrame.add(btnSearch);

        btnFetchAll.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/SunLabAccess", "root", "BErAtonouS10!");
                    Statement stmt = con.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT * FROM AccessRecord");
                    StringBuilder sb = new StringBuilder();
                    while (rs.next()) {
                        sb.append("Record ID: " + rs.getInt("recordID") + ", User ID: " + rs.getInt("studentID") + ", Timestamp: " + rs.getTimestamp("timestamp") + "\n");
                    }
                    recordsArea.setText(sb.toString());
                    rs.close();
                    stmt.close();
                    con.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        btnSearch.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String userIDInput = filterField.getText();
                if (userIDInput.isEmpty()) {
                    JOptionPane.showMessageDialog(adminFrame, "Please enter a User ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/SunLabAccess", "root", "BErAtonouS10!");

                    // Fetch records based on userID
                    String query = "SELECT * FROM AccessRecord WHERE studentID = ?";  // Use "studentID" instead of "userID" based on your database table column name
                    PreparedStatement ps = con.prepareStatement(query);

                    // Set the userID based on input from filterField
                    ps.setInt(1, Integer.parseInt(userIDInput));
                    ResultSet rs = ps.executeQuery();

                    StringBuilder sb = new StringBuilder();
                    while (rs.next()) {
                        sb.append("Record ID: " + rs.getInt("recordID") + ", User ID: " + rs.getInt("studentID") + ", Timestamp: " + rs.getTimestamp("timestamp") + "\n");
                    }

                    // Set the text of recordsArea to display fetched records
                    recordsArea.setText(sb.toString());

                    rs.close();
                    ps.close();
                    con.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(adminFrame, "Error fetching records or invalid User ID.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });



        adminFrame.setLayout(null);
        adminFrame.setVisible(true);
    }
}
